package pokerbots;

public enum Suit {
	C,
	D,
	H,
	S,
	NONE
}